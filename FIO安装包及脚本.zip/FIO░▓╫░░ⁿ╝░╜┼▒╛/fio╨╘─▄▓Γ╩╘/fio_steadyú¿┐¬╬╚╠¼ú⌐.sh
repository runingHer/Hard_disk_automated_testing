#!/bin/bash
#脚本功能
#1.按顺序测试裸盘性能（包括1m随机读、1m顺序读、1m顺序写，128k随机读、128k顺序读、128k顺序写、4k随机读、4k随机写
#2.测试1、32深度、每个测试5分钟
#3.保存完整的测试结果至/sf/log/vs/vst_perf/路径下
#4.精简结果也保存在/sf/log/vs/vst_perf/vst_diskPerf_fio中
#5. 对于混合读写，如果没有指定rwmixread或者rwmixwrite， 混合比例默认是50
#6. 对于precondition, 如果没有指定loops, 默认loops=1

#输入参数 /dev/sdX ---待测磁盘盘符

RESULT_DIR=/sf/log/vs/vst_perf

# rw_type ：    读写模型，包括read write randread randwrite
# bs_type ：    块大小，包括1m，128k，4k
# depth_type ： 深度列表，包括1,32

function do_fio_test()
{
    local filename=$1
    local rw_type=$2
    local bs_type=$3
    local depth_type=$4

    local rw_model=""
    local cmd=""
    local result_file=""

    local summary_result="$RESULT_DIR/vst_diskPerf_fio.log"
 	file_end=$(echo $filename |awk -F '/' '{print $3}')
    if [[ "$rw_type" =~ "randrw" ]];then
        rw_model="$rw_type -rwmixread=70"
    else
        rw_model="$rw_type"
    fi

	for depth in $depth_type; do
        result_file="$RESULT_DIR/fio_${bs_type}_${rw_type/=/-}_$file_end.log"
        cmd="fio -name=fiotest -filename=$filename -group_reporting -direct=1 -iodepth=$depth -ioengine=libaio -rw=$rw_model -bs=$bs_type -numjobs=1 -runtime=300"
        echo "$cmd > $result_file"
        $cmd > $result_file

        echo $result_file >> $summary_result

        if [[ "$result_file" =~ "rw" ]];then
            grep -E "read :|write:" $result_file >> $summary_result
        else
            if [[ "$result_file" =~ "read" ]];then
                grep "read :" $result_file >> $summary_result
            else
                grep "write:" $result_file >> $summary_result
            fi
        fi

    done
}

#从原始数据中过滤出吞吐量和iops
function analize_result()
{
    for file in $(find $RESULT_DIR -maxdepth 1 -type f -name "fio*.log")
    do
        echo $file
        if [[ "$file" =~ "rw" ]];then
            grep -E "read :|write:" $file
        else
            if [[ "$file" =~ "read" ]];then
                grep "read :" $file
            else
                grep "write:" $file
            fi
        fi
    done
}


function test_group()
{
    filename=$1

    #首先全盘顺序写一遍
#    fio -name=fiotest -filename=$filename -group_reporting -direct=1 -iodepth=32 -ioengine=libaio -rw=write -bs=1m -numjobs=1

 #   do_fio_test $filename randread  1M "1 32 "
 #   do_fio_test $filename read  1M "1 32 "
 #   do_fio_test $filename write 1M "1 32 "
    

    #首先全盘顺序写一遍
 fio -name=fiotest -filename=$filename -group_reporting -direct=1 -iodepth=32 -ioengine=libaio -rw=write -bs=1m -numjobs=1

    do_fio_test $filename randread  512K "32 "
    do_fio_test $filename randwrite  512K "32 "
    do_fio_test $filename randrw  512K "32 "

   fio -name=fiotest -filename=$filename -group_reporting -direct=1 -iodepth=32 -ioengine=libaio -rw=write -bs=1m -numjobs=1

    do_fio_test $filename read  512K "32 "
    do_fio_test $filename write 512K "32 "


  
    
   

    #首先全盘顺序写一遍
    fio -name=fiotest -filename=$filename -group_reporting -direct=1 -iodepth=32 -ioengine=libaio -rw=write -bs=1m -numjobs=1

    do_fio_test $filename randread 4K "32 "
    do_fio_test $filename randwrite 4K "32 "
    do_fio_test $filename randrw 4K "32 "

   fio -name=fiotest -filename=$filename -group_reporting -direct=1 -iodepth=32 -ioengine=libaio -rw=write -bs=1m -numjobs=1

   do_fio_test $filename read 4K "32 "
    do_fio_test $filename write 4K "32 "

 


}

function main()
{
    mkdir -p $RESULT_DIR
 #    local serialnum=0
    
    #TODO
    # 每次跑之前清理之前的结果
  #  find $RESULT_DIR -maxdepth 1 -type f -name "fio*.log" -exec rm -f {} \;

    cat /dev/null > $RESULT_DIR/vst_diskPerf_fio.log

    test_group $1
}

main "$@"
