#!/bin/bash
Cur_Dir=`pwd $0`
echo $Cur_Dir
fio $Cur_Dir/write-256k &

fio $Cur_Dir/read-256k &

fio $Cur_Dir/randread-4k &
 
fio $Cur_Dir/randwrite-4k &
