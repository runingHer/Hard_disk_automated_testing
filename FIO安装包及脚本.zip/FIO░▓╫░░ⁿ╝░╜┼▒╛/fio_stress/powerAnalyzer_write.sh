#!/bin/sh
killall dd
killall yes
# use yes to test CPU
#for i in {0..7}
n=$(cat /proc/cpuinfo | grep "processor" | wc -l)
for ((i=0; i<$n; i=i+1))
do 
	yes > /dev/null &  
done
sleep 1


fdisk -l 2>/dev/null | grep "^Disk.*bytes$" > tmp.txt
while read line
do
	DEV_NAME=`echo $line | awk '{print $2}' | awk -F: '{print $1}'`
	DEV_NAME_ALL="$DEV_NAME_ALL $DEV_NAME"
done < tmp.txt

for i in $DEV_NAME_ALL
do
    # FIXME
    if [ $i = "/dev/sda" ]; then
        dd if=$i of=/dev/null &
    else
        dd if=/dev/zero of=$i bs=64k &
    fi
done
#sleep 180

#killall dd
#killall yes
#echo "Finished in 5 minutes!"

