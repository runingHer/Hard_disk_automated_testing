麒麟V10服务器fio性能测试
1，安装libaio-devel.aarch64
yum install libaio-devel.aarch64
2,  安装fio测试工具
  2.1  解压fio测试程序安装包
  2.2  执行./configure
  2.3   make
  2.4   make install
  2.5 查看fio版本
        fio -v
3，执行./fio_steady.sh /dev/sdx


数据抓取：
for i in {b..l};do cat fio_4K_read_sd$i.log |grep IOPS |awk -F "," '{print $1}' |awk -F ":" '{print $2}';done;for i in {b..l};do cat fio_4K_read_sd$i.log |grep IOPS |awk -F "," '{print $2}' |awk -F "(" '{print $1}';done;for i in {b..l};do cat fio_4K_read_sd$i.log |grep lat |tail -n +3 |head -n 1 |awk -F"," '{print $3}';done

抓取randrw数据
for i in {a..d};do cat fio_4K_randrw_sd$i.log |grep IOPS |awk -F "," '{print $1}' |awk -F ":" '{print $2}';done;for i in {a..d};do cat fio_4K_randrw_sd$i.log |grep IOPS |awk -F "," '{print $2}' |awk -F "(" '{print $1}';done;for i in {a..d};do cat fio_4K_randrw_sda.log |grep "^     lat "|awk '{print $5}';done

